# silver-insta
It is a tool that extracts emails from old and new Instagram accounts
Most of the accounts are sometimes strong,
reaching 33m followers. 
Enjoy and support me 🇮🇶♥️.


# run the tool :

# First 

`pkg install php `

`pkg install screen`

`cd silver-insta`

`chmod +x *`

`screen -S bot.php`

`php bot.php`

# Second

Secondly, it will ask you for a token for the Telegram account.
Create a bot and send the token to the tool
Then put my hands on the telegram account
And go to your account and send the word start in the bot
And log in and then put an Instagram account,
you don't need a new one just to run the tool
And that's it and enjoy the hack Greetings Silver.

# telegram Channel : 

[![30%](https://img.shields.io/badge/account%20-%20telegram-blue)](https://t.me/professional_school)





# telegram account




[![30%](https://img.shields.io/badge/account-telegram-yellow)](https://t.me/iiwiw)


